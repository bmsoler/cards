define({
  "name": "API Asterisk",
  "version": "1.0.0",
  "description": "API para la comunicación entre la centralita Asterisk y Call Center de Ayesa",
  "title": "API Asterisk",
  "url": "http://172.18.74.73:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-07-28T13:11:54.185Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
