define({ "api": [
  {
    "type": "put",
    "url": "/encuestaLlamadaEntrante/:origen/:destino/:empresa",
    "title": "Realizar encuesta",
    "version": "1.0.0",
    "name": "encuestaLlamadaEntrante",
    "group": "Encuestas",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "destino",
            "description": "<p>Destino.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "origen",
            "description": "<p>Origen.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "    HTTP/1.1 404 Not Found\n    {\n      \"error\": \"Método no encontrado\"\n    }\nlogoutColas\n    HTTP/1.1 400 Bad Request\n    {\n      \"error\": \"El request no es correcto\"\n    }\n\n    HTTP/1.1 422 Unprocessable Entity\n    {\n      \"error\": \"Error en la validación\"\n    }",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Encuestas"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "respuestaEncuesta",
    "version": "1.0.0",
    "name": "respuestaEncuesta",
    "group": "Encuestas",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",\n  \"evento\": \"entraOpcion\",\n  \"idEvento\": \"1498805769.3\",\n  \"datos\": \"['1','1','5']\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Encuestas"
  },
  {
    "type": "put",
    "url": "/colgarLlamadaSaliente/:extension/:empresa",
    "title": "Colgar una llamada saliente",
    "version": "1.0.0",
    "name": "ColgarLlamadaSaliente",
    "group": "Llamadas_salientes",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión de la llamada.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio de la llamada.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Llamadas_salientes"
  },
  {
    "type": "put",
    "url": "/crearLlamada/:origen/:destino/:empresa",
    "title": "Crear una llamada saliente",
    "version": "1.0.0",
    "name": "CreaLlamada",
    "group": "Llamadas_salientes",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "origen",
            "description": "<p>Número de origen de la llamada.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "destino",
            "description": "<p>Número de destino de la llamada.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "empresa",
            "description": "<p>Empresa que realiza la llamada.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Llamadas_salientes"
  },
  {
    "type": "put",
    "url": "/desvioLocucion/:extension/:telefono/:empresa/:codigo",
    "title": "Desvíos",
    "version": "1.0.0",
    "name": "desvioLocucion",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión del agente.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "telefono",
            "description": "<p>Teléfono que se desvía.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "codigo",
            "description": "<p>Código de contexto.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "put",
    "url": "/escucharLlamadaMovil/:destino/:origen/:empresa",
    "title": "Escuchar llamada",
    "version": "1.0.0",
    "name": "escucharLlamadaMovil",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "destino",
            "description": "<p>Destino.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "origen",
            "description": "<p>Origen.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "    HTTP/1.1 404 Not Found\n    {\n      \"error\": \"Método no encontrado\"\n    }\nlogoutColas\n    HTTP/1.1 400 Bad Request\n    {\n      \"error\": \"El request no es correcto\"\n    }\n\n    HTTP/1.1 422 Unprocessable Entity\n    {\n      \"error\": \"Error en la validación\"\n    }",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "put",
    "url": "/loginColas/:extension/:cola/:empresa",
    "title": "Login Colas",
    "version": "1.0.0",
    "name": "loginColas",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión del agente.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "cola",
            "description": "<p>Nombre de la cola asociada a la extensión.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "delete",
    "url": "/loginColas/:extension/:cola/:empresa",
    "title": "Logout Cola",
    "version": "1.0.0",
    "name": "logoutColas",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión del agente.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "cola",
            "description": "<p>Nombre de la cola a abandonar.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "put",
    "url": "/pausaColas/:extension/:cola/:empresa",
    "title": "Pausar la cola",
    "version": "1.0.0",
    "name": "pausarColas",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión del agente.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Nombre",
            "description": "<p>de la cola asociada a la extensión.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "put",
    "url": "/reanudaColas/:extension/:cola/:empresa",
    "title": "Reanudar cola",
    "version": "1.0.0",
    "name": "reanudaColas",
    "group": "Operadores",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "extension",
            "description": "<p>Extensión del agente.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "cola",
            "description": "<p>Miembro de la cola a reanudar.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "empresa",
            "description": "<p>Empresa o servicio.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"code\": 200,\n  \"response\": true\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "404_Not_Found",
            "description": "<p>El servicio no ha sido encontrado.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "400_Bad_Request",
            "description": "<p>El request no es correcto.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "422_Unprocessable_Entity",
            "description": "<p>Error en la validación.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Método no encontrado\"\n}\n\nHTTP/1.1 400 Bad Request\n{\n  \"error\": \"El request no es correcto\"\n}\n\nHTTP/1.1 422 Unprocessable Entity\n{\n  \"error\": \"Error en la validación\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/main.js",
    "groupTitle": "Operadores"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "abandonaCola",
    "version": "1.0.0",
    "name": "abandonaCola",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",    \n  \"evento\": \"abandonaCola\",\n  \"idLlamada\": \"1498805769.57\",\n  \"posCola\": \"1\",\n  \"nombreCola\": \"MECD-CONVALIDACIONES\",\n  \"numeroUsuario\": \"609050027\",\n  \"tiempoEspera\": \"15\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "desenlazaLlamada",
    "version": "1.0.0",
    "name": "desenlazaLlamada",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"desenlazaLlamada\",\n  \"idLlamada\": \"1498805769.3\",\n  \"cliAgente\": \"101\",\n  \"numeroUsuario\": \"955329603\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "enlazaLlamada",
    "version": "1.0.0",
    "name": "enlazaLlamada",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"enlazaLlamada\",\n  \"idLlamada\": \"1498805769.3\",\n  \"cliAgente\": \"101\",\n  \"numeroUsuario\": \"955329603\",\n  \"tiempoEspera\": \"20\",\n  \"nombreCola\": \"MECD-CONVALIDACIONES\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "enlazaLlamadaSaliente",
    "version": "1.0.0",
    "name": "enlazaLlamadaSaliente",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"idLlamada\": \"1447056816.3\",\n  \"evento\": \"enlazaLlamadaSaliente\",\n  \"cliAgente\": \"101\",\n  \"numeroUsuario\": \"955329603\",\n  \"tiempoEspera\": \"10\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "entraCola",
    "version": "1.0.0",
    "name": "entraCola",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",    \n  \"evento\": \"entraCola\",\n  \"idLlamada\": \"1498805769.57\",\n  \"posCola\": \"1\",\n  \"nombreCola\": \"MECD-CONVALIDACIONES\",\n  \"numeroUsuario\": \"609050027\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "entraOpcion",
    "version": "1.0.0",
    "name": "entraOpcion",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"entraOpcion\",\n  \"id\": \"1498805769.3\",\n  \"opcion\": \"1\",\n  \"ruta\": \"['L200']\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "eventoEntraCentralita",
    "version": "1.0.0",
    "name": "eventoEntraCentralita",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"eventoEntraCentralita\",\n  \"telefono\": \"955329603\",\n  \"id\": \"146691163781.1116\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "eventoFueraHorario",
    "version": "1.0.0",
    "name": "eventoFueraHorario",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"eventoFueraHorario\",\n  \"telefono\": \"609050027\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "finLlamadaSaliente",
    "version": "1.0.0",
    "name": "finLlamadaSaliente",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"idLlamada\": \"1447056816.3\",\n  \"evento\": \"finLlamadaSaliente\",\n  \"tiempoTotal\": \"10\"\n  \"tiempoEspera\": \"5\"\n  \"contestado\": \"1\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "type": "socket.io",
    "url": "/",
    "title": "iniciaLlamadaSaliente (aunna_activaOpcionesLlamada*)",
    "version": "1.0.0",
    "name": "iniciaLlamadaSaliente",
    "group": "Socket_io",
    "success": {
      "examples": [
        {
          "title": "JSON emitido:",
          "content": "{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"iniciaLlamadaSaliente\",\n  \"idLlamada\": \"1498805769.3\",\n  \"origen\": \"101\",\n  \"destino\": \"955329603\"\n}\n\n{\n  \"empresa\": \"MECD\",     \n  \"evento\": \"aunna_activaOpcionesLlamada\",\n  \"idLlamada\": \"1498805769.3\",\n  \"origen\": \"101\",\n  \"destino\": \"955329603\",\n  \"channelname\": \"SIP/XXXX\"\n}\n\naunna_activaOpcionesLlamada -> Este evento emite el identificador del canal para\npoder colgar una llamada",
          "type": "json"
        }
      ]
    },
    "filename": "apidoc/api/MECD.js",
    "groupTitle": "Socket_io"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "apidoc/documentation/main.js",
    "group": "_home_lab02_workspace_ayesa_apidoc_documentation_main_js",
    "groupTitle": "_home_lab02_workspace_ayesa_apidoc_documentation_main_js",
    "name": ""
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "apidoc/template/main.js",
    "group": "_home_lab02_workspace_ayesa_apidoc_template_main_js",
    "groupTitle": "_home_lab02_workspace_ayesa_apidoc_template_main_js",
    "name": ""
  }
] });
